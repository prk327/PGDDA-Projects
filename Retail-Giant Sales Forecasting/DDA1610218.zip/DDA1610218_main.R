#-----------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------Retail Giant Sales Forecasting-----------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------------------------------

setwd("E:\\UpGrad IIIT PGDDA Program\\Course 4\\Graded Assignment\\Retail-Giant Sales Forecasting")

library(caret)
library(car)
library(MASS)
library(GGally)
library(ggplot2)
library(caTools)
library(forecast)

#----------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------Data Preparation------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------------------------------------

# # "Global Mart" is an online store super giant having worldwide operations. It takes orders and
# delivers across the globe and deals with all the major product categories - consumer, corporate &
#   home office.
# Now as a sales/operations manager, we have to finalise the plan for the next 6 months. So, we
# want to forecast the sales and the demand for the next 6 months, that would help us manage the
# revenue and inventory accordingly.
# The store caters to 7 different market segments and in 3 major categories. We want to forecast at
# this granular level, so we have to subset the data into 21 (7*3) buckets before analysing these data.
# But not all of these 21 market buckets are important from the store's point of view. So we need
# to find out 5 most profitable (and consistent) segment from these 21 and forecast the sales and
# demand for these segments.

#First we will load the data into the r enviounment and name it Global_Superstore


Global_Superstore <- read.csv("Global Superstore.csv",stringsAsFactors = F)

#we will now view this data to get a feel of it

View(Global_Superstore)

#so we see that there are 51290 observations and 24 variables, we will next check the structure of the data

str(Global_Superstore)

#we see that we have 17 character variable and 7 continious variable

#we will now check the NA values in the data sets using sappy

sapply(Global_Superstore, function(x) sum(is.na(x)))

#we see that there are 41296 na's values present in postal code, since postal code is a unique identifier of district, we should not consider postal code 
#in our final data, we will impute it with 0

Global_Superstore[which(is.na(Global_Superstore$Postal.Code)),12] <- 0

sum(is.na(Global_Superstore))

#now we will check for any duplicate values in our data sets using unique

x <- unique(Global_Superstore)

#so we don't find and duplicate rows in our data,

#we can now check the number of market segments and categories

#for that we need to convert Market to factor

Global_Superstore$Market <- as.factor(Global_Superstore$Market)

#now we need to check for the levels of markets

levels(Global_Superstore$Market)

#So we have 7 market segments consists of "Africa" "APAC"   "Canada" "EMEA"   "EU"     "LATAM"  "US", We will now check for Segment

Global_Superstore$Segment <- as.factor(Global_Superstore$Segment)

#now we need to check for the levels of category

levels(Global_Superstore$Segment)

#So we have 3 major Segment consists of "Consumer"    "Corporate"   "Home Office", We are now require to create subsets of mkt segments

Africa <- Global_Superstore[which(Global_Superstore$Market == "Africa"),]

#so in market Africa there are 4587 obs with 24 variables, we will do the same for the rest of the market segments

APAC <- Global_Superstore[which(Global_Superstore$Market == "APAC"),]

Canada <- Global_Superstore[which(Global_Superstore$Market == "Canada"),]

EMEA <- Global_Superstore[which(Global_Superstore$Market == "EMEA"),]

EU <- Global_Superstore[which(Global_Superstore$Market == "EU"),]

LATAM <- Global_Superstore[which(Global_Superstore$Market == "LATAM"),]

US <- Global_Superstore[which(Global_Superstore$Market == "US"),]

# So, we have APAC with 11002 observation, Canada with 384 OBS, EMEA with 5029 obs, EU with 10000 obs , LATAM with 10294 obs and US with 9994 OBs

#We now have to convert the data into month format for each market, since different market have different geographical location the date format
#will be different so we have to format the date for each separately

#to check for the date format we need to check the date and its range, for that we will create a new variabel of date and month in each subset

Africa_date <- as.factor(substr(Africa$Order.Date,1,2))
Africa_month <- as.factor(substr(Africa$Order.Date,4,5))
Africa_year <- as.factor(substr(Africa$Order.Date,7,10))

levels(Africa_date)
levels(Africa_month)
levels(Africa_year)

APAC_date <- as.factor(substr(APAC$Order.Date,1,2))
APAC_month <- as.factor(substr(APAC$Order.Date,4,5))


levels(APAC_date)
levels(APAC_month)

Canada_date <- as.factor(substr(Canada$Order.Date,1,2))
Canada_month <- as.factor(substr(Canada$Order.Date,4,5))

levels(Canada_date)
levels(Canada_month)

EMEA_date <- as.factor(substr(EMEA$Order.Date,1,2))
EMEA_month <- as.factor(substr(EMEA$Order.Date,4,5))

levels(EMEA_date)
levels(EMEA_month)

EU_date <- as.factor(substr(EU$Order.Date,1,2))
EU_month <- as.factor(substr(EU$Order.Date,4,5))

levels(EU_date)
levels(EU_month)

LATAM_date <- as.factor(substr(LATAM$Order.Date,1,2))
LATAM_month <- as.factor(substr(LATAM$Order.Date,4,5))

levels(LATAM_date)
levels(LATAM_month)

US_date <- as.factor(substr(US$Order.Date,1,2))
US_month <- as.factor(substr(US$Order.Date,4,5))

levels(US_date)
levels(US_month)


#we see that the format of the date is in dd/mm/yyyy for all the market segments so we don't require any formating of date we can directly convert
#the date into month format,

Global_Superstore$Order.Date <- as.Date(Global_Superstore$Order.Date,"%d-%m-%Y")

#now we will check the str of the variable order date

str(Global_Superstore)

#we see that the order date is successfully converted to date format,

#we will now order the data as per order date

Global_Superstore <- Global_Superstore[with(Global_Superstore,order(Order.Date)),]

#we see that the date was orderd successfully, now we have to create a time series of month

Global_Superstore$Order.MONYEA <- format(Global_Superstore$Order.Date,"%m-%Y")

Global_Superstore$Order.Month <- format(Global_Superstore$Order.Date,"%m")

Global_Superstore$Order.Year <- format(Global_Superstore$Order.Date,"%Y")

#we will now make the order.month variable to factor to see how many month we got for analysis

levels(as.factor(Global_Superstore$Order.MONYEA))

#so we have 48 months of time stamp, which is exactly 4 years data from 2011 to 2014.

#now we will create a DF of the order month

month_lookup <- as.data.frame(levels(as.factor(Global_Superstore$Order.MONYEA)))

colnames(month_lookup) <- c("Months")

month_lookup$Year <- substr(month_lookup$Months,4,7)

month_lookup$Tim <- substr(month_lookup$Months,1,2)

month_lookup <- month_lookup[with(month_lookup,order(Year,Tim)),]

month_lookup$TS <- seq(1:48)

#now since we have create a series of time we will use this to impute it in the main file, but first we will remove the two variable year and tim

month_lookup <- subset(month_lookup,select = c(Months,TS))

#now we will merge the TS variable in our main file

Global_Superstore_TS <- merge.data.frame(Global_Superstore,month_lookup,by.x = "Order.MONYEA",by.y = "Months",all.x = T)

#now we will check the structure of our date, and also we see that we have added pne extra variable TS in the new data frame

str(Global_Superstore_TS)

#-------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------Exploratory Data Analysis-----------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

# Outlier treatment

#now we will check for any outlier value in our continuous variables using histogram

ggplot(Global_Superstore_TS,aes(x=Sales)) + geom_histogram(col="red",fill="pink") + ggtitle("Distribution of Sales") + xlab("Sales") + ylab("Frequency") 

#we see that most of the sales are in the range 0 to 2500, and there is outliers present in this figure, we will see this using boxplot also.

boxplot(Global_Superstore_TS$Sales)

#from the above plot we can easily see that there are outliers present in Sales so we will impute it using IQR method

IQR <- as.double(quantile(Global_Superstore_TS$Sales,.75) - quantile(Global_Superstore_TS$Sales,.25))

#since our outliers are present in the upper range we will use Q3 + (IQR*1.5)

x <- as.integer(quantile(Global_Superstore_TS$Sales,0.75) + (IQR*1.5))

y <- which(Global_Superstore_TS$Sales %in% boxplot.stats(Global_Superstore_TS$Sales)$out)

Global_Superstore_TS$Sales[y] <- x

boxplot(Global_Superstore_TS$Sales)

#now we will again check for any outlier value in Quantity

ggplot(Global_Superstore_TS,aes(x=Quantity)) + geom_density(col="red",fill="pink") + ggtitle("Distribution of Quantity") + xlab("Quantity") + ylab("Frequency") 

#we see that most of the quantity are in the range 0 to 5, and the graph is left skwed so there is outliers

boxplot(Global_Superstore_TS$Quantity)

#from the above plot we can easily see that there are outliers present in quantity so we will impute it using IQR method

IQR <- as.integer(quantile(Global_Superstore_TS$Quantity,.75) - quantile(Global_Superstore_TS$Quantity,.25))

#since our outliers are present in the upper range we will use Q3 + (IQR*1.5)

x <- as.integer(quantile(Global_Superstore_TS$Quantity,0.75) + (IQR*1.5))

y <- which(Global_Superstore_TS$Quantity %in% boxplot.stats(Global_Superstore_TS$Quantity)$out)

Global_Superstore_TS$Quantity[y] <- x

boxplot(Global_Superstore_TS$Quantity)

#now we will again check for any outlier value in Discount

ggplot(Global_Superstore_TS,aes(x=Discount)) + geom_density(col="red",fill="pink") + ggtitle("Distribution of Discount") + xlab("Discount") + ylab("Frequency") 

#we see that most of the Discount are in the range 0 to 0.2.

boxplot(Global_Superstore_TS$Discount)

#we also see outliers present in discount so we will use IQR to impute the outliers

IQR <- as.double(quantile(Global_Superstore_TS$Discount,.75) - quantile(Global_Superstore_TS$Discount,.25))

#since our outliers are present in the upper range we will use Q3 + (IQR*1.5)

x <- as.double(quantile(Global_Superstore_TS$Discount,0.75) + (IQR*1.5))

y <- which(Global_Superstore_TS$Discount %in% boxplot.stats(Global_Superstore_TS$Discount)$out)

Global_Superstore_TS$Discount[y] <- x

boxplot(Global_Superstore_TS$Discount)

#now we will again check for any outlier value in Profit

ggplot(Global_Superstore_TS,aes(x=Profit)) + geom_density(col="red",fill="pink") + ggtitle("Distribution of Profit") + xlab("Profit") + ylab("Frequency") 

#we see that most of the Profit are in the range 0 .

boxplot(Global_Superstore_TS$Profit)

#we also see outliers present in Profit so we will use Quantile to check for outliers

quantile(Global_Superstore_TS$Profit,seq(0,1,0.01))

#since our outliers are present in the both upper and lower range, if we look further, the 
#profit less than 0 doesnot make sense, so we will cap all the profit less than 0 to 0, and then we will use IQR to impute the outliers 

Global_Superstore_TS$Profit[which(Global_Superstore_TS$Profit <= 0.00000)] <- 0.00000

#now since the outliers are only present in upper hinge we will use IQR

IQR <- as.double(quantile(Global_Superstore_TS$Profit,.75) - quantile(Global_Superstore_TS$Profit,.25))

#since our outliers are present in the upper range we will use Q3 + (IQR*1.5)

x <- as.double(quantile(Global_Superstore_TS$Profit,0.75) + (IQR*1.5))

y <- which(Global_Superstore_TS$Profit %in% boxplot.stats(Global_Superstore_TS$Profit)$out)

Global_Superstore_TS$Profit[y] <- x

boxplot(Global_Superstore_TS$Profit)

#now we will again check for any outlier value in Shipping.Cost

ggplot(Global_Superstore_TS,aes(x=Shipping.Cost)) + geom_density(col="red",fill="pink") + ggtitle("Distribution of Shipping.Cost") + xlab("Shipping.Cost") + ylab("Frequency") 

#we see that most of the Shipping.Cost are in the range 0 to 120.

boxplot(Global_Superstore_TS$Shipping.Cost)

#we also see outliers present in Shipping.Cost so we will use IQR to impute the outliers

IQR <- as.double(quantile(Global_Superstore_TS$Shipping.Cost,.75) - quantile(Global_Superstore_TS$Shipping.Cost,.25))

#since our outliers are present in the upper range we will use Q3 + (IQR*1.5)

x <- as.double(quantile(Global_Superstore_TS$Shipping.Cost,0.75) + (IQR*1.5))

y <- which(Global_Superstore_TS$Shipping.Cost %in% boxplot.stats(Global_Superstore_TS$Shipping.Cost)$out)

Global_Superstore_TS$Shipping.Cost[y] <- x

boxplot(Global_Superstore_TS$Shipping.Cost)

###Multivariate Analysis###

#we need to check for the correlation between continous variable so, we will create a df of continious variable only

COR_MATRIX <- subset(Global_Superstore_TS,select=c(Sales,Quantity,Discount,Profit,Shipping.Cost))

cor(COR_MATRIX)

#we see that there is a coorelation between shipping cost and profit, we will use ggplot to check visually

ggplot(Global_Superstore_TS,aes(x=Sales,y=Shipping.Cost,col = Shipping.Cost)) + geom_point() + ggtitle("Coorelation between Sales and Shipping Cost") + xlab("Sales") + ylab("Shipping Cost")

#which means the more sales the more shipping cost.
# Now we will check the structure of our data sets

str(Global_Superstore_TS)

#Since we are doing our analysis at the granular level of markets and segments and time , we won't be requiring row id,orderid,customer id, 
#customer name,postal code,product id,product name,order date, ship date and ship month which is same as ship date.

#so we will create a DF without the above variabls

retail <- subset(Global_Superstore_TS,select = c(TS,Ship.Mode,Segment,City,State,Country,Market,Region,Category,Sub.Category,Sales,Quantity,Discount,Profit,Shipping.Cost,Order.Priority))

str(retail)

#Now we will plot the time series for sales

ggplot(retail,aes(x=TS,y=Sales)) + geom_bar(stat = "identity") + ggtitle("Distribution of Sales over Months") + xlab("") + labs(fill = "Months")

#we see that there is a high sale in the months of November and december, we will now plot the time series for Quantity

ggplot(retail,aes(x=TS,y=Quantity)) + geom_bar(stat = "identity") + ggtitle("Distribution of Quantity over Months") + xlab("") + labs(fill = "Months")

#we see that there is a high demand in the months of November and december, we will now plot the time series for profit

ggplot(retail,aes(x=TS,y=Profit)) + geom_bar(stat = "identity") + ggtitle("Distribution of Profit over Months") + xlab("") + labs(fill = "Months")

#we didn't see much variation in profit from year 2013.

#----------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------Checkpoint 1:------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------------------------------------

#we need to Make the subsets of the complete dataset using the 7 factor levels of "Market" and 3 factor levels of "Segment".

#so we will create a new variable MKTSEG into retail

retail$Market <- tolower(trimws(retail$Market))

retail$Segment <- tolower(trimws(retail$Segment))

retail$MKTSEG <- paste(retail$Market,retail$Segment,sep = ",")

retail$MKTSEG <- as.factor(retail$MKTSEG)

levels(retail$MKTSEG)

#so now we have created 21 levels of market segments, now we have to find the most profitable and consistently profitable segments.

#aggregate the three time series to come at the monthly level

retail_monthly <- aggregate.data.frame(retail[,c("Profit","Sales","Quantity")],by= list(retail$TS,retail$MKTSEG),FUN = "sum")

#We will aggregate MKTSEG over coefficient of variation of profit

retail_cov <- aggregate.data.frame(retail$Profit,by=list(retail$MKTSEG),FUN = function(x) {sd(x)/mean(x)})

#now we will order coefficient of variation of profit by assending order to see the 5 most profitable and consistently profitable segments.

colnames(retail_cov) <- c("Market Segments","COV")

retail_order <- retail_cov[with(retail_cov,order(COV)),]

retail_order[1:5,]

#now the 5 most profitable and consistently profitable segments are canada,home office, eu,corporate, eu,home office, eu,consumer, canada,consumer.

#So now we have the 5 most profitable segments so we will create a DF with only these segments and will create a model on it.

#First we will check our DF which we require to build model on

#we will first create index for the 5 market segments before creating their DF

canada_home_office_index <- which(retail$MKTSEG == "canada,home office")

#now we will create DF using the above index

canada_home_office <- retail[canada_home_office_index,c(1,11:15)]

#now we will continue the same for the below segments

eu_corporate_index <- which(retail$MKTSEG == "eu,corporate")

eu_corporate <- retail[eu_corporate_index,c(1,11:15)]

#Now eu,home office

eu_home_office_index <- which(retail$MKTSEG == "eu,home office")

eu_home_office <- retail[eu_home_office_index,c(1,11:15)]

#now eu,consumer

eu_consumer_index <- which(retail$MKTSEG == "eu,consumer")

eu_consumer <- retail[eu_consumer_index,c(1,11:15)]

#now canada,consumer

canada_consumer_index <- which(retail$MKTSEG == "canada,consumer")

canada_consumer <- retail[canada_consumer_index,c(1,11:15)]

#Now we will perform aggregate operation on all five of the date sets

#now we will use the aggregate operation on it

canada_home_office_agg <- aggregate.data.frame(canada_home_office[,c("Sales","Quantity","Discount","Profit","Shipping.Cost")],by= list(canada_home_office$TS),FUN = "sum")

eu_corporate_agg <- aggregate.data.frame(eu_corporate[,c("Sales","Quantity","Discount","Profit","Shipping.Cost")],by= list(eu_corporate$TS),FUN = "sum")

eu_home_office_agg <- aggregate.data.frame(eu_home_office[,c("Sales","Quantity","Discount","Profit","Shipping.Cost")],by= list(eu_home_office$TS),FUN = "sum")

eu_consumer_agg <- aggregate.data.frame(eu_consumer[,c("Sales","Quantity","Discount","Profit","Shipping.Cost")],by= list(eu_consumer$TS),FUN = "sum")

canada_consumer_agg <- aggregate.data.frame(canada_consumer[,c("Sales","Quantity","Discount","Profit","Shipping.Cost")],by= list(canada_consumer$TS),FUN = "sum")

#now we have the total sales figure of all the top five market segments.

#we will use classical decomposition analysis of time series.. 

#----------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------Checkpoint 2:--------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------------------------------------

#before starting the model building we first need to take out 6 month data from our samples

train_1 <- canada_home_office_agg[1:19,]

train_2 <- eu_corporate_agg[1:42,]

train_3 <- eu_home_office_agg[1:42,]

train_4 <- eu_consumer_agg[1:42,]

train_5 <- canada_consumer_agg[1:36,]

#now we will Use timeser<-ts(<name# | of the variable>) to create a time series from our data sets

timeser_1 <- ts(train_1$Sales)

timeser_2 <- ts(train_2$Sales)

timeser_3 <- ts(train_3$Sales)

timeser_4 <- ts(train_4$Sales)

timeser_5 <- ts(train_5$Sales)

#Now, we will plot the time series "timeser" to get an understanding of its pattern.

plot(timeser_1)

plot(timeser_2)

plot(timeser_3)

plot(timeser_4)

plot(timeser_5)

#we will repeat the same for Quantity

timeser_Q1 <- ts(train_1$Quantity)

timeser_Q2 <- ts(train_2$Quantity)

timeser_Q3 <- ts(train_3$Quantity)

timeser_Q4 <- ts(train_4$Quantity)

timeser_Q5 <- ts(train_5$Quantity)

#Now, we will plot the time series "timeser" to get an understanding of its pattern.

plot(timeser_Q1)

plot(timeser_Q2)

plot(timeser_Q3)

plot(timeser_Q4)

plot(timeser_Q5)

#we see that the time series has an increasing trend and also a seasonality factor with a constant amplitude.

#we will first smoothen the given time series. Because of simplicity, we will first use the moving average smoothing method.
# Note that, in this method the size of the time series decreases from both ends due to smoothing. So, we will first smoothen the series with the
# minimum window size, i.e 3.

#To smoothen the time series with moving average method with a window size of 3, use smoothedseries<-filter(<name of the time series>,| filter=rep(1/3,3), method=<method name>, sides=2)

smooth_timeser_1 <- filter(timeser_1, filter=rep(1/3, 3), method='convolution', sides=2)

smooth_timeser_2 <- filter(timeser_2, filter=rep(1/3, 3), method='convolution', sides=2)

smooth_timeser_3 <- filter(timeser_3, filter=rep(1/3, 3), method='convolution', sides=2)

smooth_timeser_4 <- filter(timeser_4, filter=rep(1/3, 3), method='convolution', sides=2)

smooth_timeser_5 <- filter(timeser_5, filter=rep(1/3, 3), method='convolution', sides=2)

#Next, we will plot the smoothed time series to check if the smoothing is appropriate. Use lines(<name of the smoothed time series>, col="red",| lwd=2)

plot(timeser_1)

lines(smooth_timeser_1, col="red", lwd=2)

plot(timeser_2)

lines(smooth_timeser_2, col="red", lwd=2)

plot(timeser_3)

lines(smooth_timeser_3, col="red", lwd=2)

plot(timeser_4)

lines(smooth_timeser_4, col="red", lwd=2)

plot(timeser_5)

lines(smooth_timeser_5, col="red", lwd=2)

#we will repeat the same for Quantity

smooth_timeser_Q1 <- filter(timeser_Q1, filter=rep(1/3, 3), method='convolution', sides=2)

smooth_timeser_Q2 <- filter(timeser_Q2, filter=rep(1/3, 3), method='convolution', sides=2)

smooth_timeser_Q3 <- filter(timeser_Q3, filter=rep(1/3, 3), method='convolution', sides=2)

smooth_timeser_Q4 <- filter(timeser_Q4, filter=rep(1/3, 3), method='convolution', sides=2)

smooth_timeser_Q5 <- filter(timeser_Q5, filter=rep(1/3, 3), method='convolution', sides=2)

#Next, we will plot the smoothed time series to check if the smoothing is appropriate. Use lines(<name of the smoothed time series>, col="red",| lwd=2)

plot(timeser_Q1)

lines(smooth_timeser_Q1, col="red", lwd=2)

plot(timeser_Q2)

lines(smooth_timeser_Q2, col="red", lwd=2)

plot(timeser_Q3)

lines(smooth_timeser_Q3, col="red", lwd=2)

plot(timeser_Q4)

lines(smooth_timeser_Q4, col="red", lwd=2)

plot(timeser_Q5)

lines(smooth_timeser_Q5, col="red", lwd=2)

#the smoothing done is quite appropriate for building the model. So, it is of no use to further increase the window size for smoothing as it will lead to loss of points.

#To form a regression model, we need to to form a dataframe of the smoothed series which includes the "month" column as well. Use smoothed<-data.frame(cbind(<name of the month variable in the train data set>,smoothedseries))

smooth_Sales_train_1 <- data.frame(cbind(train_1$Group.1,train_1$Quantity,train_1$Discount,train_1$Profit,train_1$Shipping.Cost,smooth_timeser_1))

colnames(smooth_Sales_train_1) <- c("Month","Quantity","Discount","Profit","Shipping_Cost","Sales")

smooth_Sales_train_2 <- data.frame(cbind(train_2$Group.1,train_2$Quantity,train_2$Discount,train_2$Profit,train_2$Shipping.Cost,smooth_timeser_2))

colnames(smooth_Sales_train_2) <- c("Month","Quantity","Discount","Profit","Shipping_Cost","Sales")

smooth_Sales_train_3 <- data.frame(cbind(train_3$Group.1,train_3$Quantity,train_3$Discount,train_3$Profit,train_3$Shipping.Cost,smooth_timeser_3))

colnames(smooth_Sales_train_3) <- c("Month","Quantity","Discount","Profit","Shipping_Cost","Sales")

smooth_Sales_train_4 <- data.frame(cbind(train_4$Group.1,train_4$Quantity,train_4$Discount,train_4$Profit,train_4$Shipping.Cost,smooth_timeser_4))

colnames(smooth_Sales_train_4) <- c("Month","Quantity","Discount","Profit","Shipping_Cost","Sales")

smooth_Sales_train_5 <- data.frame(cbind(train_5$Group.1,train_5$Quantity,train_5$Discount,train_5$Profit,train_5$Shipping.Cost,smooth_timeser_5))

colnames(smooth_Sales_train_5) <- c("Month","Quantity","Discount","Profit","Shipping_Cost","Sales")

#we will repeat the same for the quantity as well

smooth_Quantity_train_1 <- data.frame(cbind(train_1$Group.1,train_1$Sales,train_1$Discount,train_1$Profit,train_1$Shipping.Cost,smooth_timeser_Q1))

colnames(smooth_Quantity_train_1) <- c("Month","Sales","Discount","Profit","Shipping_Cost","Quantity")

smooth_Quantity_train_2 <- data.frame(cbind(train_2$Group.1,train_2$Sales,train_2$Discount,train_2$Profit,train_2$Shipping.Cost,smooth_timeser_Q2))

colnames(smooth_Quantity_train_2) <- c("Month","Sales","Discount","Profit","Shipping_Cost","Quantity")

smooth_Quantity_train_3 <- data.frame(cbind(train_3$Group.1,train_3$Sales,train_3$Discount,train_3$Profit,train_3$Shipping.Cost,smooth_timeser_Q3))

colnames(smooth_Quantity_train_3) <- c("Month","Sales","Discount","Profit","Shipping_Cost","Quantity")

smooth_Quantity_train_4 <- data.frame(cbind(train_4$Group.1,train_4$Sales,train_4$Discount,train_4$Profit,train_4$Shipping.Cost,smooth_timeser_Q4))

colnames(smooth_Quantity_train_4) <- c("Month","Sales","Discount","Profit","Shipping_Cost","Quantity")

smooth_Quantity_train_5 <- data.frame(cbind(train_5$Group.1,train_5$Sales,train_5$Discount,train_5$Profit,train_5$Shipping.Cost,smooth_timeser_Q5))

colnames(smooth_Quantity_train_5) <- c("Month","Sales","Discount","Profit","Shipping_Cost","Quantity")

#Note that because of smoothing, the first and the last data point is shown as NA. So, we need to replace the NAs with appropriate values.

# To replace the first datapoint, we will calculate the difference between the second and third datapoint. Then, subtract this difference from the
# value of the second data point to get the value of the first data point. To find the difference, use diff_1<-<difference of the third and the
# second datapoint>

Diff_1_smooth_Sales_train_1 <- smooth_Sales_train_1$Sales[3]-smooth_Sales_train_1$Sales[2]

#subtract this difference from the value of the second data point to get the value of the first datapoint. Use smoothed$demand[1]<-<second
# datapoint> - diff_1

smooth_Sales_train_1$Sales[1] <- smooth_Sales_train_1$Sales[2]-Diff_1_smooth_Sales_train_1

#Similarly, to replace the last datapoint, we will calculate the difference between the second last and third last datapoint
#Then, add this difference to the value of the second last data point to get the value of the last data point.
#To find the difference, use diff_2<-<difference of the third last and the second last datapoint>

Diff_2_smooth_Sales_train_1 <- smooth_Sales_train_1$Sales[nrow(smooth_Sales_train_1)-1]-smooth_Sales_train_1$Sales[nrow(smooth_Sales_train_1)-2]

#Now, add this difference to the value of the second last data point to get the value of the last datapoint.

smooth_Sales_train_1$Sales[nrow(smooth_Sales_train_1)] <- smooth_Sales_train_1$Sales[nrow(smooth_Sales_train_1)-1]+Diff_2_smooth_Sales_train_1

#now we will repeat the same for rest of the series

#----------

Diff_1_smooth_Sales_train_2 <- smooth_Sales_train_2$Sales[3]-smooth_Sales_train_2$Sales[2]

#subtract this difference from the value of the second data point to get the value of the first datapoint. Use smoothed$demand[1]<-<second
# datapoint> - diff_1

smooth_Sales_train_2$Sales[1] <- smooth_Sales_train_2$Sales[2]-Diff_1_smooth_Sales_train_2

#Similarly, to replace the last datapoint, we will calculate the difference between the second last and third last datapoint
#Then, add this difference to the value of the second last data point to get the value of the last data point.
#To find the difference, use diff_2<-<difference of the third last and the second last datapoint>

Diff_2_smooth_Sales_train_2 <- smooth_Sales_train_2$Sales[nrow(smooth_Sales_train_2)-1]-smooth_Sales_train_2$Sales[nrow(smooth_Sales_train_2)-2]

#Now, add this difference to the value of the second last data point to get the value of the last datapoint.

smooth_Sales_train_2$Sales[nrow(smooth_Sales_train_2)] <- smooth_Sales_train_2$Sales[nrow(smooth_Sales_train_2)-1]+Diff_2_smooth_Sales_train_2

#---------
  
Diff_1_smooth_Sales_train_3 <- smooth_Sales_train_3$Sales[3]-smooth_Sales_train_3$Sales[2]

#subtract this difference from the value of the second data point to get the value of the first datapoint. Use smoothed$demand[1]<-<second
# datapoint> - diff_1

smooth_Sales_train_3$Sales[1] <- smooth_Sales_train_3$Sales[2]-Diff_1_smooth_Sales_train_3

#Similarly, to replace the last datapoint, we will calculate the difference between the second last and third last datapoint
#Then, add this difference to the value of the second last data point to get the value of the last data point.
#To find the difference, use diff_2<-<difference of the third last and the second last datapoint>

Diff_2_smooth_Sales_train_3 <- smooth_Sales_train_3$Sales[nrow(smooth_Sales_train_3)-1]-smooth_Sales_train_3$Sales[nrow(smooth_Sales_train_3)-2]

#Now, add this difference to the value of the second last data point to get the value of the last datapoint.

smooth_Sales_train_3$Sales[nrow(smooth_Sales_train_3)] <- smooth_Sales_train_3$Sales[nrow(smooth_Sales_train_3)-1]+Diff_2_smooth_Sales_train_3

#---------
  
Diff_1_smooth_Sales_train_4 <- smooth_Sales_train_4$Sales[3]-smooth_Sales_train_4$Sales[2]

#subtract this difference from the value of the second data point to get the value of the first datapoint. Use smoothed$demand[1]<-<second
# datapoint> - diff_1

smooth_Sales_train_4$Sales[1] <- smooth_Sales_train_4$Sales[2]-Diff_1_smooth_Sales_train_4

#Similarly, to replace the last datapoint, we will calculate the difference between the second last and third last datapoint
#Then, add this difference to the value of the second last data point to get the value of the last data point.
#To find the difference, use diff_2<-<difference of the third last and the second last datapoint>

Diff_2_smooth_Sales_train_4 <- smooth_Sales_train_4$Sales[nrow(smooth_Sales_train_4)-1]-smooth_Sales_train_4$Sales[nrow(smooth_Sales_train_4)-2]

#Now, add this difference to the value of the second last data point to get the value of the last datapoint.

smooth_Sales_train_4$Sales[nrow(smooth_Sales_train_4)] <- smooth_Sales_train_4$Sales[nrow(smooth_Sales_train_4)-1]+Diff_2_smooth_Sales_train_4

#------
  
  
Diff_1_smooth_Sales_train_5 <- smooth_Sales_train_5$Sales[3]-smooth_Sales_train_5$Sales[2]

#subtract this difference from the value of the second data point to get the value of the first datapoint. Use smoothed$demand[1]<-<second
# datapoint> - diff_1

smooth_Sales_train_5$Sales[1] <- smooth_Sales_train_5$Sales[2]-Diff_1_smooth_Sales_train_5

#Similarly, to replace the last datapoint, we will calculate the difference between the second last and third last datapoint
#Then, add this difference to the value of the second last data point to get the value of the last data point.
#To find the difference, use diff_2<-<difference of the third last and the second last datapoint>

Diff_2_smooth_Sales_train_5 <- smooth_Sales_train_5$Sales[nrow(smooth_Sales_train_5)-1]-smooth_Sales_train_5$Sales[nrow(smooth_Sales_train_5)-2]

#Now, add this difference to the value of the second last data point to get the value of the last datapoint.

smooth_Sales_train_5$Sales[nrow(smooth_Sales_train_5)] <- smooth_Sales_train_5$Sales[nrow(smooth_Sales_train_5)-1]+Diff_2_smooth_Sales_train_5

#now we will repeat the same for quantity


Diff_1_smooth_Quantity_train_1 <- smooth_Quantity_train_1$Quantity[3]-smooth_Quantity_train_1$Quantity[2]

#subtract this difference from the value of the second data point to get the value of the first datapoint. Use smoothed$demand[1]<-<second
# datapoint> - diff_1

smooth_Quantity_train_1$Quantity[1] <- smooth_Quantity_train_1$Quantity[2]-Diff_1_smooth_Quantity_train_1

#Similarly, to replace the last datapoint, we will calculate the difference between the second last and third last datapoint
#Then, add this difference to the value of the second last data point to get the value of the last data point.
#To find the difference, use diff_2<-<difference of the third last and the second last datapoint>

Diff_2_smooth_Quantity_train_1 <- smooth_Quantity_train_1$Quantity[nrow(smooth_Quantity_train_1)-1]-smooth_Quantity_train_1$Quantity[nrow(smooth_Quantity_train_1)-2]

#Now, add this difference to the value of the second last data point to get the value of the last datapoint.

smooth_Quantity_train_1$Quantity[nrow(smooth_Quantity_train_1)] <- smooth_Quantity_train_1$Quantity[nrow(smooth_Quantity_train_1)-1]+Diff_2_smooth_Quantity_train_1

#---------------
  
Diff_1_smooth_Quantity_train_2 <- smooth_Quantity_train_2$Quantity[3]-smooth_Quantity_train_2$Quantity[2]

#subtract this difference from the value of the second data point to get the value of the first datapoint. Use smoothed$demand[1]<-<second
# datapoint> - diff_1

smooth_Quantity_train_2$Quantity[1] <- smooth_Quantity_train_2$Quantity[2]-Diff_1_smooth_Quantity_train_2

#Similarly, to replace the last datapoint, we will calculate the difference between the second last and third last datapoint
#Then, add this difference to the value of the second last data point to get the value of the last data point.
#To find the difference, use diff_2<-<difference of the third last and the second last datapoint>

Diff_2_smooth_Quantity_train_2 <- smooth_Quantity_train_2$Quantity[nrow(smooth_Quantity_train_2)-1]-smooth_Quantity_train_2$Quantity[nrow(smooth_Quantity_train_2)-2]

#Now, add this difference to the value of the second last data point to get the value of the last datapoint.

smooth_Quantity_train_2$Quantity[nrow(smooth_Quantity_train_2)] <- smooth_Quantity_train_2$Quantity[nrow(smooth_Quantity_train_2)-1]+Diff_2_smooth_Quantity_train_2

#--------------------
  
Diff_1_smooth_Quantity_train_3 <- smooth_Quantity_train_3$Quantity[3]-smooth_Quantity_train_3$Quantity[2]

#subtract this difference from the value of the second data point to get the value of the first datapoint. Use smoothed$demand[1]<-<second
# datapoint> - diff_1

smooth_Quantity_train_3$Quantity[1] <- smooth_Quantity_train_3$Quantity[2]-Diff_1_smooth_Quantity_train_3

#Similarly, to replace the last datapoint, we will calculate the difference between the second last and third last datapoint
#Then, add this difference to the value of the second last data point to get the value of the last data point.
#To find the difference, use diff_2<-<difference of the third last and the second last datapoint>

Diff_2_smooth_Quantity_train_3 <- smooth_Quantity_train_3$Quantity[nrow(smooth_Quantity_train_3)-1]-smooth_Quantity_train_3$Quantity[nrow(smooth_Quantity_train_3)-2]

#Now, add this difference to the value of the second last data point to get the value of the last datapoint.

smooth_Quantity_train_3$Quantity[nrow(smooth_Quantity_train_3)] <- smooth_Quantity_train_3$Quantity[nrow(smooth_Quantity_train_3)-1]+Diff_2_smooth_Quantity_train_3


#------------
  

Diff_1_smooth_Quantity_train_4 <- smooth_Quantity_train_4$Quantity[3]-smooth_Quantity_train_4$Quantity[2]

#subtract this difference from the value of the second data point to get the value of the first datapoint. Use smoothed$demand[1]<-<second
# datapoint> - diff_1

smooth_Quantity_train_4$Quantity[1] <- smooth_Quantity_train_4$Quantity[2]-Diff_1_smooth_Quantity_train_4

#Similarly, to replace the last datapoint, we will calculate the difference between the second last and third last datapoint
#Then, add this difference to the value of the second last data point to get the value of the last data point.
#To find the difference, use diff_2<-<difference of the third last and the second last datapoint>

Diff_2_smooth_Quantity_train_4 <- smooth_Quantity_train_4$Quantity[nrow(smooth_Quantity_train_4)-1]-smooth_Quantity_train_4$Quantity[nrow(smooth_Quantity_train_4)-2]

#Now, add this difference to the value of the second last data point to get the value of the last datapoint.

smooth_Quantity_train_4$Quantity[nrow(smooth_Quantity_train_4)] <- smooth_Quantity_train_4$Quantity[nrow(smooth_Quantity_train_4)-1]+Diff_2_smooth_Quantity_train_4

#---------------
  
Diff_1_smooth_Quantity_train_5 <- smooth_Quantity_train_5$Quantity[3]-smooth_Quantity_train_5$Quantity[2]

#subtract this difference from the value of the second data point to get the value of the first datapoint. Use smoothed$demand[1]<-<second
# datapoint> - diff_1

smooth_Quantity_train_5$Quantity[1] <- smooth_Quantity_train_5$Quantity[2]-Diff_1_smooth_Quantity_train_5

#Similarly, to replace the last datapoint, we will calculate the difference between the second last and third last datapoint
#Then, add this difference to the value of the second last data point to get the value of the last data point.
#To find the difference, use diff_2<-<difference of the third last and the second last datapoint>

Diff_2_smooth_Quantity_train_5 <- smooth_Quantity_train_5$Quantity[nrow(smooth_Quantity_train_5)-1]-smooth_Quantity_train_5$Quantity[nrow(smooth_Quantity_train_5)-2]

#Now, add this difference to the value of the second last data point to get the value of the last datapoint.

smooth_Quantity_train_5$Quantity[nrow(smooth_Quantity_train_5)] <- smooth_Quantity_train_5$Quantity[nrow(smooth_Quantity_train_5)-1]+Diff_2_smooth_Quantity_train_5

##Now, we will fit the regression model. But before that, we need to decide the features to be used for the model. Recall that the series has a
# seasonality with constant amplitude. So, we will use sine/cosine function. We may also use a combination of both, but here we will use sine
# function. Also, the series has a linear trend, so there must be a term of "month" to take care of the trend.

#so, lets build the regression model. Use lmfit <- lm(<name of the dependent variable> ~ smoothed$sin(0.5*(month - pi/2)) + smoothed$month,data=<name of the dataframe>)

Reg_sales_1 <- lm(smooth_Sales_train_1$Sales ~ sin(0.5 * (smooth_Sales_train_1$Month - pi /2)) + smooth_Sales_train_1$Month + smooth_Sales_train_1$Quantity + smooth_Sales_train_1$Discount + smooth_Sales_train_1$Profit + smooth_Sales_train_1$Shipping_Cost,data = smooth_Sales_train_1)

Reg_sales_2 <- lm(smooth_Sales_train_2$Sales ~ sin(0.5 * (smooth_Sales_train_2$Month - pi /2)) + smooth_Sales_train_2$Month + smooth_Sales_train_2$Quantity + smooth_Sales_train_2$Discount + smooth_Sales_train_2$Profit + smooth_Sales_train_2$Shipping_Cost,data = smooth_Sales_train_2)

Reg_sales_3 <- lm(smooth_Sales_train_3$Sales ~ sin(0.5 * (smooth_Sales_train_3$Month - pi /2)) + smooth_Sales_train_3$Month + smooth_Sales_train_3$Quantity + smooth_Sales_train_3$Discount + smooth_Sales_train_3$Profit + smooth_Sales_train_3$Shipping_Cost,data = smooth_Sales_train_3)

Reg_sales_4 <- lm(smooth_Sales_train_4$Sales ~ sin(0.5 * (smooth_Sales_train_4$Month - pi /2)) + smooth_Sales_train_4$Month + smooth_Sales_train_4$Quantity + smooth_Sales_train_4$Discount + smooth_Sales_train_4$Profit + smooth_Sales_train_4$Shipping_Cost,data = smooth_Sales_train_4)

Reg_sales_5 <- lm(smooth_Sales_train_5$Sales ~ sin(0.5 * (smooth_Sales_train_5$Month - pi /2)) + smooth_Sales_train_5$Month + smooth_Sales_train_5$Quantity + smooth_Sales_train_5$Discount + smooth_Sales_train_5$Profit + smooth_Sales_train_5$Shipping_Cost,data = smooth_Sales_train_5)

#repeat the same for quantity

Reg_Quantity_1 <- lm(smooth_Quantity_train_1$Quantity ~ sin(0.5 * (smooth_Quantity_train_1$Month - pi /2)) + smooth_Quantity_train_1$Month + smooth_Quantity_train_1$Sales + smooth_Quantity_train_1$Discount + smooth_Quantity_train_1$Profit + smooth_Quantity_train_1$Shipping_Cost,data = smooth_Quantity_train_1)

Reg_Quantity_2 <- lm(smooth_Quantity_train_2$Quantity ~ sin(0.5 * (smooth_Quantity_train_2$Month - pi /2)) + smooth_Quantity_train_2$Month + smooth_Quantity_train_2$Sales + smooth_Quantity_train_2$Discount + smooth_Quantity_train_2$Profit + smooth_Quantity_train_2$Shipping_Cost,data = smooth_Quantity_train_2)

Reg_Quantity_3 <- lm(smooth_Quantity_train_3$Quantity ~ sin(0.5 * (smooth_Quantity_train_3$Month - pi /2)) + smooth_Quantity_train_3$Month + smooth_Quantity_train_3$Sales + smooth_Quantity_train_3$Discount + smooth_Quantity_train_3$Profit + smooth_Quantity_train_3$Shipping_Cost,data = smooth_Quantity_train_3)

Reg_Quantity_4 <- lm(smooth_Quantity_train_4$Quantity ~ sin(0.5 * (smooth_Quantity_train_4$Month - pi /2)) + smooth_Quantity_train_4$Month + smooth_Quantity_train_4$Sales + smooth_Quantity_train_4$Discount + smooth_Quantity_train_4$Profit + smooth_Quantity_train_4$Shipping_Cost,data = smooth_Quantity_train_4)

Reg_Quantity_5 <- lm(smooth_Quantity_train_5$Quantity ~ sin(0.5 * (smooth_Quantity_train_5$Month - pi /2)) + smooth_Quantity_train_5$Month + smooth_Quantity_train_5$Sales + smooth_Quantity_train_5$Discount + smooth_Quantity_train_5$Profit + smooth_Quantity_train_5$Shipping_Cost,data = smooth_Quantity_train_5)

### Next, we will want to visualise the series predicted by the model as compared to the original time series. So, first predict the value of demand
# for the smoothed dataset. Use trend<-predict(<name of the model>, data.frame(<name of the month column of the smoothed dataset>)).

trent_sales_1 <- predict(Reg_sales_1,data.frame(smooth_Sales_train_1$Month))

trent_sales_2 <- predict(Reg_sales_2,data.frame(smooth_Sales_train_2$Month))

trent_sales_3 <- predict(Reg_sales_3,data.frame(smooth_Sales_train_3$Month))

trent_sales_4 <- predict(Reg_sales_4,data.frame(smooth_Sales_train_4$Month))

trent_sales_5 <- predict(Reg_sales_5,data.frame(smooth_Sales_train_5$Month))

#will use the same for quantity

trent_Quantity_1 <- predict(Reg_Quantity_1,data.frame(smooth_Quantity_train_1$Month))

trent_Quantity_2 <- predict(Reg_Quantity_2,data.frame(smooth_Quantity_train_2$Month))

trent_Quantity_3 <- predict(Reg_Quantity_3,data.frame(smooth_Quantity_train_3$Month))

trent_Quantity_4 <- predict(Reg_Quantity_4,data.frame(smooth_Quantity_train_4$Month))

trent_Quantity_5 <- predict(Reg_Quantity_5,data.frame(smooth_Quantity_train_5$Month))


##Next, we will plot the predicted time series to compare its accuracy with the smoothed series.

plot(timeser_1)

lines(smooth_Sales_train_1$Month, trent_sales_1, col='blue', lwd=2)

plot(timeser_2)

lines(smooth_Sales_train_2$Month, trent_sales_2, col='blue', lwd=2)

plot(timeser_3)

lines(smooth_Sales_train_3$Month, trent_sales_3, col='blue', lwd=2)

plot(timeser_4)

lines(smooth_Sales_train_4$Month, trent_sales_4, col='blue', lwd=2)

plot(timeser_5)

lines(smooth_Sales_train_5$Month, trent_sales_5, col='blue', lwd=2)

#now we will plot for quantity

plot(timeser_Q1)

lines(smooth_Quantity_train_1$Month, trent_Quantity_1, col='blue', lwd=2)

plot(timeser_Q2)

lines(smooth_Quantity_train_2$Month, trent_Quantity_2, col='blue', lwd=2)


plot(timeser_Q3)

lines(smooth_Quantity_train_3$Month, trent_Quantity_3, col='blue', lwd=2)

plot(timeser_Q4)

lines(smooth_Quantity_train_4$Month, trent_Quantity_4, col='blue', lwd=2)

plot(timeser_Q5)

lines(smooth_Quantity_train_5$Month, trent_Quantity_5, col='blue', lwd=2)

##Note that the built model athough fits the trend very nicely, but the amplitude arising due to the seasonality factor is not that well fitted.
# Let's now try building arima model on the same dataset.

#Now, we will build the arima model on the "timeser" variable. Use autoarima <- auto.arima(<name of the timeseries>).

arima_timeser_1 <- auto.arima(timeser_1)

arima_timeser_2 <- auto.arima(timeser_2)

arima_timeser_3 <- auto.arima(timeser_3)

arima_timeser_4 <- auto.arima(timeser_4)

arima_timeser_5 <- auto.arima(timeser_5)

#Will do the same for Quantity

arima_timeser_Q1 <- auto.arima(timeser_Q1)

arima_timeser_Q2 <- auto.arima(timeser_Q2)

arima_timeser_Q3 <- auto.arima(timeser_Q3)

arima_timeser_Q4 <- auto.arima(timeser_Q4)

arima_timeser_Q5 <- auto.arima(timeser_Q5)

#Now we will Again, plot the original time series "timeser" to comapre it with arima model. Use plot()

plot(timeser_1)

lines(fitted(arima_timeser_1), col="red")

plot(timeser_2)

lines(fitted(arima_timeser_2), col="red")

plot(timeser_3)

lines(fitted(arima_timeser_3), col="red")

plot(timeser_4)

lines(fitted(arima_timeser_4), col="red")

plot(timeser_5)

lines(fitted(arima_timeser_5), col="red")

#we will predict the same for Quantity

plot(timeser_Q1)

lines(fitted(arima_timeser_Q1), col="red")

plot(timeser_Q2)

lines(fitted(arima_timeser_Q2), col="red")

plot(timeser_Q3)

lines(fitted(arima_timeser_Q3), col="red")

plot(timeser_Q4)

lines(fitted(arima_timeser_Q4), col="red")

plot(timeser_Q5)

lines(fitted(arima_timeser_Q5), col="red")

#Note that in this case, the arima model gives a much better model as compared to the classical decomposition case. However, for time series timeser_1,timeser_5 and timeser_Q5
#the arima models perform poorly. We will now check the accuracy of the two model.

## To check the order (p,d,q) of the arima model, print the arima model. Type "autoarima" in R.

arima_timeser_1 #p=0,d=0,q=0

arima_timeser_2 #p=2,d=1,q=0

arima_timeser_3 #p=2,d=1,q=0

arima_timeser_4 #p=2,d=1,q=0

arima_timeser_5 #p=0,d=0,q=0

arima_timeser_Q1 #p=2,d=1,q=0

arima_timeser_Q2 #p=2,d=1,q=0

arima_timeser_Q3 #p=2,d=1,q=0

arima_timeser_Q4 #p=2,d=1,q=0

arima_timeser_Q5 #p=0,d=0,q=0

#We see that except model arima_timeser_1,arima_timeser_5,arima_timeser_Q5 the stationary series has been obtained by differencing once on which an ARMA(2,0) has been fitted.

#Next, we will build the tsdiagram of the arima model to check the various features of the built model. Use tsdiag(<name of the arima model>).

tsdiag(arima_timeser_1)

tsdiag(arima_timeser_2)

tsdiag(arima_timeser_3)

tsdiag(arima_timeser_4)

tsdiag(arima_timeser_5)

tsdiag(arima_timeser_Q1)

tsdiag(arima_timeser_Q2)

tsdiag(arima_timeser_Q3)

tsdiag(arima_timeser_Q4)

tsdiag(arima_timeser_Q5)


#----------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------Checkpoint 3:--------------------------------------------------------------------------
#----------------------------------------------------------------------------------------------------------------------------------------------------

#we will use timeser_2,timeser_3,timeser_4 to predict since only these three model have all the 48 months data

Model_2_Forcast <- forecast.Arima(arima_timeser_2,h=6)

Model_3_Forcast <- forecast.Arima(arima_timeser_3,h=6)

Model_4_Forcast <- forecast.Arima(arima_timeser_4,h=6)

Model_Q2_Forcast <- forecast.Arima(arima_timeser_Q2,h=6)

Model_Q3_Forcast <- forecast.Arima(arima_timeser_Q3,h=6)

Model_Q4_Forcast <- forecast.Arima(arima_timeser_Q4,h=6)

## We will plot to see seek

plot(Model_Q4_Forcast)

plot(Model_Q3_Forcast)

plot(Model_Q2_Forcast)

plot(Model_2_Forcast)

plot(Model_3_Forcast)

plot(Model_4_Forcast)

## extract point forecasts

round(accuracy(Model_2_Forcast,eu_corporate_agg$Sales),3)



#---------------------------------------------------------END---------------------------------------------------------------------


