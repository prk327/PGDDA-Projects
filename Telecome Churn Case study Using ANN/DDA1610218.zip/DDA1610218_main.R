#-------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------Telecome Churn Case study------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

library(h2o)
library(caret)
library(car)
library(MASS)
library(GGally)
library(ggplot2)
library(caTools)

setwd("E:\\UpGrad IIIT PGDDA Program\\Course 4\\Graded Assignment")

#-------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------Data Preparation---------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

#Loading the file in the enviournment 

churn_raw <- read.csv("telecom_nn_train.csv",stringsAsFactors = F)

#Now we will check the structure of the file

View(churn_raw)

str(churn_raw)

#we will also check the summary of the data sets

summary(churn_raw)

#we see that there are 4930 observations and 31 variable including one dependent variable "Churn"

#Now we will check for any missing values

apply(churn_raw,2,function(x) sum(is.na(x)))

#we see that there are 6 NA variables under total charges, since total charges is a continuous variable we will impute NA's with continuous variable 
#But before that we will check the values of other variable, we will store the index of na's values in the below variable

index_of_na <- which(is.na(churn_raw$TotalCharges))

#we will now look at the valus of the NA's variables by using the index on churn_raw

x <- churn_raw[index_of_na,]

View(x)

#we see that the monthly charges are in between 19 to 57, so we will check for the median value of totalcharges which lies under monthly charges of
#19 to 57

index_of_monthly_charges <- which(churn_raw$MonthlyCharges >= 19 & churn_raw$MonthlyCharges <= 57)

#lets see that values for the above range

y <- churn_raw[index_of_monthly_charges,]

#now we will check for the median of the totak charges on above data frame

median_of_tChar <- median(y$TotalCharges,na.rm = T)

#now we will impute the median value to the na values in the raw file

churn_raw[index_of_na,9] <- median_of_tChar

#now we will again check for any na's in our data file

apply(churn_raw,2,function(x) sum(is.na(x)))

#we now don't have any NA values in our files

#we will also remove any duplicate rows from our data sets

churn_unique <- unique(churn_raw)

#we see that 10 obserations has been removed from our data sets as they are duplicate

#we also need to conver our dependent variable to factor for our further analysis

churn_unique$Churn <- as.factor(churn_unique$Churn)

#-------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------Exploratory Data Analysis-----------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

###Univariate Analysis###

# Summary Statistics
# Distribution plot
# Outlier treatment

summary(churn_unique)

#now we will check for any outlier value in our continuous variables using density plot

ggplot(churn_unique,aes(x=tenure)) + geom_histogram(col="red",fill="pink",bins = 30) + ggtitle("Distribution of Tenure") + xlab("Tenure") + ylab("Frequency") 

#we see that most people are having tenure less than 10

#we see that distribution doesnot seems to have any outliers, but for our sake we will check is using boxplot also

boxplot(churn_unique$tenure)

#we don't see any any outliers present in tenure so we will move towards monthly charges

ggplot(churn_unique,aes(x=MonthlyCharges)) + geom_density(col="red",fill="pink") + ggtitle("Distribution of Monthly Charges") + xlab("Monthly Charges") + ylab("Density") 

#we see that the density of monthly charges is high at charges 75 to 100

#now we will check for boxplot

boxplot(churn_unique$MonthlyCharges)

#we don't see any any outliers present in MonthlyCharges so we will move towards total charges

ggplot(churn_unique,aes(x=TotalCharges)) + geom_density(col="red",fill="pink") + ggtitle("Distribution of Total Charges") + xlab("Total Charges") + ylab("Density") 

#we see that most customer are having monthly charges less than 2500

#we will check the outlies using boxplot

boxplot(churn_unique$TotalCharges)

#there is not outliers present in total charges, now we will move towards multivariate analysis

###Multivariate Analysis###

#we need to check for the correlation between continous variable so, we will create a df of continious variable only

churn_cont <- churn_unique[,c("tenure","MonthlyCharges","TotalCharges")]

#now we will use ggally to se the covariance plot

ggpairs(churn_cont)

#we see that tenure and total charges are corelated and hav correlation of 0.821

#we will also check this using ggplot

ggplot(churn_unique,aes(x=tenure,y=TotalCharges,col=TotalCharges)) + geom_point() + ggtitle("Correlation between total charges over tenure") + xlab("Tenure") + ylab("")

#we seethat if the tenure increases total charges also increases

#we need to see the effect of demography on dependant variable

ggplot(churn_unique,aes(x=churn_unique$gender,fill=factor(Churn))) + geom_bar(position = "stack") + ggtitle("Distribution of Churn over Gender") + xlab("Gender") + ylab("Count") + labs(fill="Churn")

#we see that there is equal distribution of gender over churn

ggplot(churn_unique,aes(x=churn_unique$SeniorCitizen,fill=factor(Churn))) + geom_bar(position = "fill") + ggtitle("Distribution of Churn over SeniorCitizen") + xlab("Senior Citizen") + ylab("") + labs(fill="Churn")

#we see that about 700 observation are senior citizen and about 43% are churn, while theres are 3200 who are not senior citizen and less than 25% churn

ggplot(churn_unique,aes(x=churn_unique$Partner,fill=factor(Churn))) + geom_bar(position = "fill") + ggtitle("Distribution of Churn over Partner") + xlab("Partner") + ylab("") + labs(fill="Churn")

#we see that less than 25% churn who have partner

ggplot(churn_unique,aes(x=churn_unique$OnlineSecurityYes,fill=factor(Churn))) + geom_bar(position = "fill") + ggtitle("Distribution of Churn over Online Security") + xlab("Online Security") + ylab("") + labs(fill="Churn")

#we see that about 13% of the customer churn who have online security

#Now we will check our data frame is see if it is in the correct format

str(churn_unique)

#now we will require to standardize the final df

churn_scale <- data.frame(scale.default(churn_unique[,-10]))

#now we will combine the dependant variabe to the scale data frame

churn <- cbind(churn_unique[,10],churn_scale)

#we will rename the dependant variabe to churn

colnames(churn)[1] <- "Churn"

#we now require to change the col in factor

churn$Churn <- as.factor(churn$Churn)

#Now again we will check our data frame is see if it is in the correct format

str(churn)

#-------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------Checkpoint 1 Model Building---------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

#The first step is split the dataset into training and test dataset. For this, we will split the row index in the ratio of 75:25 in a variable "index".
#since we are doing a classification problem which have dependance variable yes and no, we will use sample.split

index <- sample.split(churn$Churn,SplitRatio = 0.75)


#lets see the value of indices

index

# There are 75% TRUE and 25% FALSE values in this vector. We can now assign the TRUE indices as the train data and FALSE indices as the test data.

train <- churn[index == T,]

#now lets check the structure of the train ds

str(train)

#so the train data set have 3690 obs with 31 variables
#now lets create test data sets

test <- churn[index == F,]

#so our test data sets is of 1230 obs and 31 variables

#To build the NN model, we will use the h2o package which requires the dataset to be in different format.

#To use the h2o package, first initialise the h2o environment.

h2o.init()

#Now store the training dataset in a .csv format and store it in a variable "train.csv".

write.csv(train,file = "train.csv",row.names = F)

#Similarly, store the test dataset in a .csv format and store it in a variable "test.csv".

write.csv(test,file = "test.csv",row.names = F)

#Now, we need to import the .csv files using h2o.importFile() command so as to make it compatible with the h2o package.

#Firstly, import the training dataset.

train1 <- h2o.importFile("train.csv")

#Similarly, import the test dataset.

test1 <- h2o.importFile("test.csv")

#The next step is to build the NN model. Here, we will use the "TanhWithDropout" activation function with three hidden layers and hidden drop out ratio of 0.1.

#So, Let's build the NN model. Use nnet <- h2o.deeplearning(names(train1[, -14]), names(<name of the dependent variable>), <name of the train dataset>, distribution
#| = "gaussian", activation = "TanhWithDropout", hidden = c(100, 100, 100), hidden_dropout_ratios = c(0.1, 0.1, 0.1), epochs = 10).

Model_1 <- h2o.deeplearning(names(train1[,-1]),names(train1[,1]),train1,distribution = "bernoulli",activation = "TanhWithDropout",hidden = c(100,100,100),hidden_dropout_ratios = c(0.1,0.1,0.1),epochs = -1)

#Note that in the above model we have used the distribution as bernoulli because it is a binomial data. Once the model is built, let us next predict the value of
#model on the training dataset and find out its accuracy, Sensitivity, and Specificity.

#we need to check the stat of the model

summary(Model_1)

pred_train <- as.data.frame(h2o.predict(Model_1,train1[,-1]))

#now we will construct confusion matrix with train data

confusionMatrix(pred_train$predict,train$Churn)

#so we have 16 true positive and 952 true negative

#with Accuracy : 0.2623, Sensitivity : 0.005852, Specificity : 0.995816

#now we will construct confusion matrix on test data, but first we need to predict the value on test data

pred_test <- as.data.frame(h2o.predict(Model_1,test1[,-1]))

#now we will construct confusion matrix on test data

confusionMatrix(pred_test$predict,test$Churn)

#so we have 2 true positive and 317 true negative

#with Accuracy : 0.2593, Sensitivity : 0.002193, Specificity : 0.993730

#we can say that the above model can predict with 99% accuracy the customers who will churn.
# For this model I have selected hidden layer of 3 with 100 neurons and a dropout rate of 10%, with -1 epoch and activation function TanhWithDropout, which gives an overall accuracy of 26%
#specificity of 99 and sensitivity of 0.002, which will tend to predict all the good customer to bad customer.



#-------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------Model Building 2----------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

#now we can use the same formula to create a new model with different hyperparameter

Model_2 <- h2o.deeplearning(names(train1[,-1]),names(train1[,1]),train1,distribution = "bernoulli",activation = "RectifierWithDropout",hidden = c(100,100,100),hidden_dropout_ratios = c(0.1,0.1,0.1),epochs = -1)

#Note that in the above model we have used the distribution as bernoulli because it is a binomial data. Once the model is built, let us next predict the value of
#model on the training dataset and find out its accuracy, Sensitivity, and Specificity.

#we need to check the stat of the model

summary(Model_2)

pred_train <- as.data.frame(h2o.predict(Model_2,train1[,-1]))

#now we will construct confusion matrix with train data

confusionMatrix(pred_train$predict,train$Churn)

#so we have 1238 true positive and 687 true negative

#with Accuracy : 0.5217, Sensitivity : 0.4528, Specificity : 0.7186

#now we will construct confusion matrix on test data, but first we need to predict the value on test data

pred_test <- as.data.frame(h2o.predict(Model_2,test1[,-1]))

#now we will construct confusion matrix on test data

confusionMatrix(pred_test$predict,test$Churn)

#so we have 427 true positive and 233 true negative

#with Accuracy : 0.5366, Sensitivity : 0.4687, Specificity : 0.7304

#we can say that the above model can predict with 73% accuracy the customers who will churn.

#In this model we have change our activation function to "RectifierWithDropout", which increases overall accuracy to 53%,sensitivity to 46% and
#specificity to 73%, which we can say an slightly improvement.

#-------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------Model Building 3----------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

#now we can use the same formula to create a new model with different hyperparameter

Model_3 <- h2o.deeplearning(names(train1[,-1]),names(train1[,1]),train1,distribution = "bernoulli",activation = "MaxoutWithDropout",hidden = c(100,100,100),hidden_dropout_ratios = c(0.1,0.1,0.1),epochs = -1)

#Note that in the above model we have used the distribution as bernoulli because it is a binomial data. Once the model is built, let us next predict the value of
#model on the training dataset and find out its accuracy, Sensitivity, and Specificity.

#we need to check the stat of the model

summary(Model_3)

pred_train <- as.data.frame(h2o.predict(Model_3,train1[,-1]))

#now we will construct confusion matrix with train data

confusionMatrix(pred_train$predict,train$Churn)

#so we have 226 true positive and 877 true negative

#with Accuracy : 0.2989, Sensitivity : 0.08266, Specificity : 0.91736

#now we will construct confusion matrix on test data, but first we need to predict the value on test data

pred_test <- as.data.frame(h2o.predict(Model_3,test1[,-1]))

#now we will construct confusion matrix on test data

confusionMatrix(pred_test$predict,test$Churn)

#so we have 78 true positive and 295 true negative

#with Accuracy : 0.3033, Sensitivity : 0.08562, Specificity : 0.92476

#we can say that the above model can predict with 92% accuracy the customers who will churn.

#In this model we have use "MaxoutWithDropout" as our activation and we see that out accuracy is panalized and also it is predicting all the customers
#as churn, which result badly in classification



#-------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------Checkpoint 2 Model Building---------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

#now we need to build a model which train in batches

Model_4 <- h2o.deeplearning(names(train1[,-1]),names(train1[,1]),train1,distribution = "bernoulli",activation = "RectifierWithDropout",hidden = c(100,100,100),hidden_dropout_ratios = c(0.1,0.1,0.1),epochs = 10)

#Note that in the above model we have used the distribution as bernoulli because it is a binomial data. Once the model is built, let us next predict the value of
#model on the training dataset and find out its accuracy, Sensitivity, and Specificity.

#we need to check the stat of the model

summary(Model_4)

pred_train <- as.data.frame(h2o.predict(Model_4,train1[,-1]))

#now we will construct confusion matrix with train data

confusionMatrix(pred_train$predict,train$Churn)

#so we have 2246 true positive and 683 true negative

#with Accuracy : 0.7938, Sensitivity : 0.8215, Specificity : 0.7144

#now we will construct confusion matrix on test data, but first we need to predict the value on test data

pred_test <- as.data.frame(h2o.predict(Model_4,test1[,-1]))

#now we will construct confusion matrix on test data

confusionMatrix(pred_test$predict,test$Churn)

#so we have 743 true positive and 235 true negative

#with Accuracy : 0.7951, Sensitivity : 0.8156, Specificity : 0.7367

#So, in this model we have use activation "RectifierWithDropout" to train our data batch wise and we see that, it improves the accuracy to 79% for 
#both train and test data.

#-------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------Model Building 1--------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

#now we need to build a model which train in batches

Model_5 <- h2o.deeplearning(names(train1[,-1]),names(train1[,1]),train1,distribution = "bernoulli",activation = "RectifierWithDropout",hidden = c(100,100,100),hidden_dropout_ratios = c(0.1,0.1,0.1),epochs = 20)

#Note that in the above model we have used the distribution as bernoulli because it is a binomial data. Once the model is built, let us next predict the value of
#model on the training dataset and find out its accuracy, Sensitivity, and Specificity.

#we need to check the stat of the model

summary(Model_5)

pred_train <- as.data.frame(h2o.predict(Model_5,train1[,-1]))

#now we will construct confusion matrix with train data

confusionMatrix(pred_train$predict,train$Churn)

#so we have 2276 true positive and 696 true negative

#with Accuracy : 0.8054, Sensitivity : 0.8325, Specificity : 0.7280

#now we will construct confusion matrix on test data, but first we need to predict the value on test data

pred_test <- as.data.frame(h2o.predict(Model_5,test1[,-1]))

#now we will construct confusion matrix on test data

confusionMatrix(pred_test$predict,test$Churn)

#so we have 745 true positive and 231 true negative

#with Accuracy : 0.7935, Sensitivity : 0.8178, Specificity : 0.7241

#we see that once we have increase the epoch to 20 it predicts well on the training data with 80% accuracy and works good on test data with 79%
#accuracy, so we will next increase our epoch to see if the overall accuracy increases or not.

#-------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------Model Building 2--------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

#now we need to build a model which train in batches

Model_6 <- h2o.deeplearning(names(train1[,-1]),names(train1[,1]),train1,distribution = "bernoulli",activation = "RectifierWithDropout",hidden = c(100,100,100),hidden_dropout_ratios = c(0.2,0.3,0.2),epochs = 1000)

#Note that in the above model we have used the distribution as bernoulli because it is a binomial data. Once the model is built, let us next predict the value of
#model on the training dataset and find out its accuracy, Sensitivity, and Specificity.

#we need to check the stat of the model

summary(Model_6)

pred_train <- as.data.frame(h2o.predict(Model_6,train1[,-1]))

#now we will construct confusion matrix with train data

confusionMatrix(pred_train$predict,train$Churn)

#so we have 2657 true positive and 891 true negative

#with Accuracy : 0.9615, Sensitivity : 0.9718, Specificity : 0.9320

#now we will construct confusion matrix on test data, but first we need to predict the value on test data

pred_test <- as.data.frame(h2o.predict(Model_6,test1[,-1]))

#now we will construct confusion matrix on test data

confusionMatrix(pred_test$predict,test$Churn)

#so we have 781 true positive and 164 true negative

#with Accuracy : 0.7683, Sensitivity : 0.8573, Specificity : 0.5141

#we see that if we  increase the no of epoch rate the model tends to memorized the training data and gives a accuracy of 96% overall, but if we verify on
#test data it perform very badly with just 76% accuracy. So now we will try to increase the dropout rate to see if the model works the same on the test data.

#-------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------Model Building 3--------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

#we see that if we increase the neurons, the model will tend to memorize the train set, and if we increase the dropout rate the neurons tends to 
#loose the valuable weights and also if we increase the epoch the model will become unsatable,

Model_7 <- h2o.deeplearning(names(train1[,-1]),names(train1[,1]),train1,distribution = "bernoulli",activation = "RectifierWithDropout",hidden = c(200,200,200),hidden_dropout_ratios = c(0.4,0.5,0.3),epochs = 50)

#Note that in the above model we have used the distribution as bernoulli because it is a binomial data. Once the model is built, let us next predict the value of
#model on the training dataset and find out its accuracy, Sensitivity, and Specificity.

#we need to check the stat of the model

summary(Model_7)

pred_train <- as.data.frame(h2o.predict(Model_7,train1[,-1]))

#now we will construct confusion matrix with train data

confusionMatrix(pred_train$predict,train$Churn)

#so we have 2208 true positive and 722 true negative

#with Accuracy : 0.794, Sensitivity : 0.8076, Specificity : 0.7552

#now we will construct confusion matrix on test data, but first we need to predict the value on test data

pred_test <- as.data.frame(h2o.predict(Model_7,test1[,-1]))

#now we will construct confusion matrix on test data

confusionMatrix(pred_test$predict,test$Churn)

#so we have 728 true positive and 241 true negative

#with Accuracy : 0.7878, Sensitivity : 0.7991, Specificity : 0.7555

#we see that if we increase neurons , and also the drop out rate the model tends to generalised. In the next model we will try to see if any of the parameter 
#can give us a better model.

#-------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------Model Building 4--------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------

#we will again tune our model to get the bettwr accuracy 

Model_8 <- h2o.deeplearning(names(train1[,-1]),names(train1[,1]),train1,distribution = "bernoulli",activation = "RectifierWithDropout",hidden = c(200,200,200),hidden_dropout_ratios = c(0.4,0.5,0.4),epochs = 85)

#Note that in the above model we have used the distribution as bernoulli because it is a binomial data. Once the model is built, let us next predict the value of
#model on the training dataset and find out its accuracy, Sensitivity, and Specificity.

#we need to check the stat of the model

summary(Model_8)

pred_train <- as.data.frame(h2o.predict(Model_8,train1[,-1]))

#now we will construct confusion matrix with train data

confusionMatrix(pred_train$predict,train$Churn)

#so we have 2243 true positive and 734 true negative

#with Accuracy : 0.8068, Sensitivity : 0.8204, Specificity : 0.7678

#now we will construct confusion matrix on test data, but first we need to predict the value on test data

pred_test <- as.data.frame(h2o.predict(Model_8,test1[,-1]))

#now we will construct confusion matrix on test data

confusionMatrix(pred_test$predict,test$Churn)

#so we have 721 true positive and 244 true negative

#with Accuracy : 0.7846, Sensitivity : 0.7914, Specificity : 0.7649

#we can say that the above model can predict with 79% accuracy the customers who will not churn and 76% accuracy the churn customer


#-------------------------------------------------------------------------------------------------------------------------------------------------
#-------------------------------------------------------------Final Recommendation----------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------


#So we can twik the model to get which metric we require most to solve a problem, We see that if we don't train the model batch wise we are getting 
#a Specificity of 92% on model 3 and sensitivity of 0.08% which means that the model will predict that all the customer will churn, which is not a solution
#to our problem, We also see if we introduce batch training our overall accuracy increases in model_4 and then we continued twiking that model until
#we get to the optimum model, We have use the fine tuining and got a optimal model_8 which performs well on training and as well as on test data
# and can predict churn customer in both train and test data with 76% accuracy.

#-------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------------The End------------------------------------------------------------------------
#-------------------------------------------------------------------------------------------------------------------------------------------------



 