setwd("E:\\UpGrad IIIT PGDDA Program\\Course 4\\Graded Assignment\\ARM - Global Mart")

install.packages("arules", dependencies=TRUE)

install.packages("arulesViz")

library(arulesViz)
library(arules)

#-----------------------------------------------------------------------------------------------------------------------------------------------------
#------------------------------------------------------------Assignment - Association Rule Mining-----------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------------------------------

#We Have a Business Problem As Stated Below:-

#Business Problem

# We want to figure out the most frequently occurring combination of the items that are bought together. This would
# enable us to recommend the related items to a customer, once he makes a purchase in the store.

#So, First lets load the raw data into R,

Global_Superstore <- read.csv("Global Superstore.csv",stringsAsFactors = F)

#Now lets chekc the data using view

View(Global_Superstore)

#We see that the data is prepared category wise, and not as per individual transaction. We know from the problem statement that "each row of the dataset represents an item of the order. However, the Order
# ID is not unique. Thus, the different items ordered at a time figure in different rows with the
# same Order ID. The number of unique products is too large a number to provide meaningful
# insight. Thus, the most relevant attribute to analyse would be the "Sub-Category" of the
# products.



#-----------------------------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------Checkpoint 1: (Data Understanding & Data Preparation)--------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------------------------------

#So, Now we have to bring the items brought with same order id at a same time frame into individual rows,and for this we require order id, order date and subcategory

#So, Since the granularity of my date is these three variables, I will prepare my data as per the unique variable in each of this three column

#but first I will subset the date with these variable only

Global_Superstore <- subset(Global_Superstore,select=c(Order.ID,Order.Date,Sub.Category))

Global_Superstore$Order.ID <- trimws(tolower(Global_Superstore$Order.ID))

Global_Superstore$Order.Date <- trimws(tolower(Global_Superstore$Order.Date))

Global_Superstore$Sub.Category <- trimws(tolower(Global_Superstore$Sub.Category))

#now we need to create a new variable which will act as an unique identifyer

Global_Superstore$Unique <- paste(Global_Superstore$Order.ID,Global_Superstore$Order.Date,Global_Superstore$Sub.Category,sep = ",")

#Now we will check for any duplicate row which is common in this Unique column.

dupli <- which(duplicated(Global_Superstore$Unique))

#now we will check if the rows are actually duplicate or not

x <- Global_Superstore[dupli,]

View(x)

#we see that for order ID ae-2014-3830 on 13-12-2014 we have phones,storage,art and binders, where storage and binders are repeting 2nd time, so we need to 
#remove those items from the unique transaction since it doesnot make sense to include single item two times in one transaction on same day by same customer.

#so we will now remove those duplicate rows

Global_Superstore_Unique <- Global_Superstore[-dupli,]

#now we will again check order ID ae-2014-3830 to see if there is any repeated item are there .

View(Global_Superstore_Unique)

#we see that there is no repeat for any item in order id ae-2014-3830, so now we have all the unique transaction as per order id, date and subcategory

#now we will check for  individual sub category.

x <- unique(Global_Superstore$Sub.Category)

#so we have 17 sub category, lets create 17 dummy variable

df.matrix <-
  function(x, name = "dummy")
    for (i in 1:ncol(x)) {
      if (class(x[, i]) == "factor") {
        y <- NA
        y <- data.frame(rep(0, nrow(x)))
        for (j in 1:(nlevels(x[, i]))) {
          y[, j] <- rep(0, nrow(x))
          colnames(y)[j] <-
            paste(levels(x[, i])[j])
          y[which(x[, i] == levels(x[, i])[j]), j] <- 1
        }
        assign(paste(name, colnames(x[i]), sep = "_"),
               y,
               environment(df.matrix))
      }
    }

#to run the above function we need to change the sub-category to factor type

str(Global_Superstore_Unique)

#we see that none of the variable are of fator type, so we safely create sub-category to factor type, since the above function will only create
#dummy variable of factor column

Global_Superstore_Unique$Sub.Category <- as.factor(Global_Superstore_Unique$Sub.Category)

str(Global_Superstore_Unique)

#we see that sub-category ischnage to factor class, now we will create dummy variable of sub-category

df.matrix(Global_Superstore_Unique)

#now we can combine the unique variable with the subcategory

Global_Superstore_category <- cbind(Global_Superstore_Unique,dummy_Sub.Category)

#now we have one more important steps to take which is to create a column of order id and order date, so that we can have unique transaction in one row

Global_Superstore_category$transaction <- paste(Global_Superstore_category$Order.ID,Global_Superstore_category$Order.Date,sep = ",")

#now we need to again check for any duplicate in our transaction variable

trans_dup <- which(duplicated(Global_Superstore_category$transaction))

#now we will impute the index of duplicate transaction into row to view the duplicate transaction

x <- Global_Superstore_category[trans_dup,]

#now we will view x

View(x)

#now we will take order id ae-2011-9160 on 03-10-2011 to see if it's a duplicate or not

View(Global_Superstore_category)

#we see that this order has two items machine and storage in two rows, and column machines has 1 and storage has 1, so we won't delete row 
#from this data sets, instead we will aggregate by variable transaction

#now we can use the aggregate function to get all the unique transaction into one row, before that we have note down one transaction order
#ID in-2012-48240 which has 5 sub-category, ie: tables, phones, binders, labels, envelopes, we would like to have these 5 transaction in one row

store_transaction <- aggregate.data.frame(Global_Superstore_category[,5:21],by=list(Global_Superstore_category$transaction),FUN = "sum")

#so now we will search for transaction in-2012-48240 to see if all the 5 items were in one row or not

View(store_transaction)

#we see that all items are there in the row so we have 25752 transaction with 17 items

#We can also verify that none of the column have any number outside 0 and 1

# Now we need to Convert the transaction level data into transaction format .

#before that we need to remove the transaction column arules function to work

items_matrix <- as.matrix(store_transaction[,-1])

#now we will convert this matrix to transaction using below function

matrix_basket <- function(x, name = "trans") {
  y <- NA
  y <- c(rep(0, nrow(x)))
  for (i in 1:nrow(x)) {
    for (j in 1:ncol(x)) {
      if (x[i, j] == 1) {
        y[i] <-
          trimws(sub("0,", "", paste(y[i], colnames(x)[j], sep = ",")))
      }
    }
  }
  assign(paste(name), y, environment(matrix_basket))
}

#So, the above function will create a vector of all the individual transaction where items are seperated by comma, which will represent basket transaction

#now we will apply the above function to our item_matrix file

matrix_basket(items_matrix)

#now we will save the file in the local drive 

write(trans,file = "trans.dat")

#Now we will read the above file using arules read.transaction command

item_sets <- read.transactions(file="trans.dat",format="basket",sep=",")

#Quotes are introduced in transactions, which are unnecessary and result in some incorrect results. So, we must get rid of them:

item_sets@itemInfo$labels <- gsub("\"","",item_sets@itemInfo$labels)

#lets check the transaction file by typing item_sets

item_sets

#we see that there are 25752 transaction with 2619 items


#So, to get an intial understanding of the data set check the plot of all the items indicating their frequency.

itemFrequencyPlot(item_sets,topN=20,type="absolute")

## the plot shows the top 20 items which have been purchased frequently in order of their frequency. It can be observed that Binders is purchased very
# frequently.

#-----------------------------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------Checkpoint 2: (Association Rule Mining)----------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------------------------------

# From a business point of view of a departmental store, an appropriate placement of frequently bought products can help in the increment of sales and also lead to
# better customer satisfaction as it might reduce the customer's purchase time.

#However, if you have package 'tm' attached in the session, it creates a conflict with the arules package. Thus, we need to check and detach the package.

if(sessionInfo()['basePkgs']=="tm" | sessionInfo()['otherPkgs']=="tm"){
  detach(package:tm, unload=TRUE)
}

#So, let's start building the association rules using the apriori algorithm. Considering minimum support of 0.001 and minimum confidence of 0.80. Use rules<-apriori(<name
#  of the dataset>, parameter = list(support = <min. support>, confidence = <min. confidence>)).

store_rules <- apriori(item_sets, parameter = list(support = 0.01, confidence = 0.20,target = "rules",maxlen = 10))

#To get a sense of the candidates of association rules, check the number of rules generated. Type rules.

store_rules

inspect(store_rules)

df_store_rules <- as(store_rules,"data.frame")

#Plot a few graphs that can help you visualize the rules. Install and load the 'arulesViz' library for association rules specific visualizations:

plot(store_rules)

#so to get a maxlen len of4 we are getting 4 rules, and if we increase confidence we would be getting only 0 rules, so we can say that the 
#max item of 4 will be machines, appliances, paper and binders

#Note that binders appears in almost all the rules in the RHS. So, we might be curious to know what other things do people buy when they buy binders.

#To form such rules, take binders in the lhs of the rule and consider minimum confidence of 10%. Create such rules using rulebinders <- subset(<name of the variable with rules>, subset = lhs %in% "binders" & confidence>0.10).

store_rules_1 <- apriori(item_sets, parameter = list(support = 0.01, confidence = 0.10,target = "rules"))
 
rulebinders<-subset(store_rules_1, subset = lhs %in% "binders" & confidence>0.10)

#these rules are also not sorted. So, first let's sort the rules in decreasing order by confidence. Use rulebinders<-sort(<name of the variable with rules>, by="confidence", decreasing=TRUE).

rulebinders<-sort(rulebinders, by="confidence", decreasing=TRUE)

#Now, to see the top 5 rules by confidence, use inspect(<name of the variable with the rules>[1:5])

inspect(rulebinders)

#we see that at <10% confidence customer who buys binders also buys storage, art, paper, phone, chair, furniture and acessories.

plot(store_rules_1)

#-----------------------------------------------------------------------------------------------------------------------------------------------------
#----------------------------------------------------Checkpoint 3: (Rule Relevance/Evaluation)----------------------------------------------------------
#-----------------------------------------------------------------------------------------------------------------------------------------------------

#The numerical value of the support, confidence and the lift level for the itemsets/rule

#Support is 0.01 confidence = 0.20 lift = 1.0

#since the rules says that machines, appliances paper and binders are frequently brought together which completely makes sense, and since binder
# is the most common it can go woth any three of the items.

#So the businees can safely choose to put any two item or, three or all four items in one place to let the customer make less effort in adding those 
#items in their carts.


#----------------------------------------------------------------THE END-------------------------------------------------------------------------------------



  